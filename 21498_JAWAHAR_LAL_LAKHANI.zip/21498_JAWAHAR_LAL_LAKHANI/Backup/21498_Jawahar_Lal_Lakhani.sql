/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.27-MariaDB : Database - 21498_jawahar_lal_lakhani
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`21498_jawahar_lal_lakhani` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `21498_jawahar_lal_lakhani`;

/*Table structure for table `blog` */

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `blog_title` varchar(200) DEFAULT NULL,
  `post_per_page` int(11) DEFAULT NULL,
  `blog_background_image` text DEFAULT NULL,
  `blog_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`blog_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `blog` */

insert  into `blog`(`blog_id`,`user_id`,`blog_title`,`post_per_page`,`blog_background_image`,`blog_status`,`created_at`,`updated_at`) values 
(19,NULL,'Travel',10,'1716702692_men-723557_1280.jpg','Active','2024-05-26 10:51:32',NULL),
(20,NULL,'Nature',10,'1716703743_nature.jpg','Active','2024-05-26 11:09:03',NULL),
(21,NULL,'Technology',12,'1716704013_images.jpeg','Active','2024-05-26 11:13:33',NULL),
(22,NULL,'Singing',10,'1716704273_images (1).jpeg','Active','2024-05-26 11:17:53',NULL);

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_title` varchar(100) DEFAULT NULL,
  `category_description` text DEFAULT NULL,
  `category_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category_title`,`category_description`,`category_status`,`created_at`,`updated_at`) values 
(3,'Box','lorem lorem ','Active','2024-05-21 11:00:24','2024-05-21 11:00:19'),
(5,'boxing ','Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...\"\r\n\"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain...\"','Active','2024-05-22 12:23:42','2024-05-22 12:23:37'),
(6,'What is Lorem Ipsum?','lal','Active','2024-05-23 10:06:08','2024-05-23 10:06:04'),
(7,'It is a long established fact that a reader will be distracted by the readable content of a page whe','It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum isIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is','Active','2024-05-23 10:07:48',NULL),
(8,'HidayaTrust','monly used to demonstrate the visual form of a document or a','Active','2024-05-23 10:36:07',NULL),
(9,'Exploring','There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which','Active','2024-05-24 15:46:24',NULL),
(10,'Art','Art is a diverse range of human activity and its resulting product that involves creative or imaginative talent generally expressive of technical ..Art is a diverse range of human activity and its resulting product that involves creative or imaginative talent generally expressive of technical ..','Active','2024-05-27 10:03:53',NULL);

/*Table structure for table `following_blog` */

DROP TABLE IF EXISTS `following_blog`;

CREATE TABLE `following_blog` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) DEFAULT NULL,
  `blog_following_id` int(11) DEFAULT NULL,
  `status` enum('Followed','Unfollowed') DEFAULT 'Followed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`follow_id`),
  KEY `blog_following_id` (`blog_following_id`),
  KEY `follower_id` (`follower_id`),
  CONSTRAINT `following_blog_ibfk_1` FOREIGN KEY (`blog_following_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `following_blog_ibfk_2` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `following_blog` */

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) DEFAULT NULL,
  `post_title` varchar(200) NOT NULL,
  `post_summary` text NOT NULL,
  `post_description` longtext NOT NULL,
  `featured_image` text DEFAULT NULL,
  `post_status` enum('Active','InActive') DEFAULT NULL,
  `is_comment_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`post_id`),
  KEY `blog_id` (`blog_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post` */

insert  into `post`(`post_id`,`blog_id`,`post_title`,`post_summary`,`post_description`,`featured_image`,`post_status`,`is_comment_allowed`,`created_at`,`updated_at`) values 
(21,19,'Digital Marketing','Digital marketing, also called online marketing, is the promotion of brands to connect with potential customers using the internet and other forms of digital communication.','Digital marketing, also called online marketing, is the promotion of brands to connect with potential customers using the internet and other forms of digital communication. This includes not only email, social media, and web-based advertising, but also text and multimedia messages as a marketing channel.Digital marketing, also called online marketing, is the promotion of brands to connect with potential customers using the internet and other forms of digital communication. This includes not only email, social media, and web-based advertising, but also text and multimedia messages as a marketing channel.','1716706822_digital.jpeg','Active',1,'2024-05-26 17:50:40','2024-05-26 12:00:22'),
(22,21,'PHP Course','A popular general-purpose scripting language that is especially suited to web development. Fast, flexible and pragmatic, PHP powers everything from your blog ','PHP is a general-purpose scripting language geared towards web development. It was originally created by Danish-Canadian programmer Rasmus Lerdorf in 1993 and released in 1995. The PHP reference implementation is now produced by the PHP Group.','1716706964_php.png','Active',1,'2024-05-26 17:50:54','2024-05-26 12:02:44'),
(23,21,'Graphic designing','Graphic design is a profession, academic discipline and applied art whose activity consists in projecting visual communications intended visual communications intended ','Graphic design is a profession, academic discipline and applied art whose activity consists in projecting visual communications intended to transmit specific messages to social groups, with specific objectives. Graphic design is an interdisciplinary branch of design and of the fine arts.Graphic design is a profession, academic discipline and applied art whose activity consists in projecting visual communications intended to transmit specific messages to social groups, with specific objectives. Graphic design is an interdisciplinary branch of design and of the fine arts.','1716707106_graphic.jpeg','Active',1,'2024-05-27 10:21:26','2024-05-26 12:05:06'),
(24,19,'In publishing','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc varius est id porta tincidunt. Praesent eget congue nisi. Mauris id dapibus sem. Ut congue tortor a erat consectetur, id iaculis orci viverra.','Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Etiam est dolor, feugiat id blandit ac, vulputate sed metus. Curabitur elementum nunc non odio dignissim, sit amet consequat quam venenatis. Etiam ultricies enim erat, sit amet egestas orci vulputate in. Vivamus viverra velit fermentum, ultricies nisl in, laoreet erat. Proin eu consequat velit. Nulla facilisi.','1716711863_images.jpeg','Active',1,'2024-05-26 17:51:07','2024-05-26 13:24:23'),
(25,19,'HIST','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc varius est id porta tincidunt. Praesent eget congue nisi. Mauris id dapibus sem. Ut congue tortor a erat consectetur, id iaculis orci viverra. ',' Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Etiam est dolor, feugiat id blandit ac, vulputate sed metus. Curabitur elementum nunc non odio dignissim, sit amet consequat quam venenatis. Etiam ultricies enim erat, sit amet egestas orci vulputate in. Vivamus viverra velit fermentum, ultricies nisl in, laoreet erat. Proin eu consequat velit. Nulla facilisi.','1716711948_men-723557_1280.jpg','Active',1,'2024-05-26 17:51:13','2024-05-26 13:25:48'),
(26,19,'Literature','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc varius est id porta tincidunt. Praesent eget congue nisi. Mauris id dapibus sem. Ut congue tortor a erat consectetur, id iaculis orci viverra.','Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Etiam est dolor, feugiat id blandit ac, vulputate sed metus. Curabitur elementum nunc non odio dignissim, sit amet consequat quam venenatis. Etiam ultricies enim erat, sit amet egestas orci vulputate in. Vivamus viverra velit fermentum, ultricies nisl in, laoreet erat. Proin eu consequat velit. Nulla facilisi.','1716712101_nature.jpg','Active',1,'2024-05-26 17:51:20','2024-05-26 13:28:21'),
(27,NULL,'HIST','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relyingIn publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying','1716743813_php.png','Active',1,'2024-05-26 22:16:53','2024-05-26 22:16:53'),
(28,NULL,'Art/Design','Art is a diverse range of human activity and its resulting product that involves creative or imaginative talent generally expressive of technical ..','Art is a diverse range of human activity and its resulting product that involves creative or imaginative talent generally expressive of technical ..Art is a diverse range of human activity and its resulting product that involves creative or imaginative talent generally expressive of technical ..Art is a diverse range of human activity and its resulting product that involves creative or imaginative talent generally expressive of technical ..','1716785852_graphic.jpeg','Active',1,'2024-05-27 11:06:45','2024-05-27 09:57:32');

/*Table structure for table `post_atachment` */

DROP TABLE IF EXISTS `post_atachment`;

CREATE TABLE `post_atachment` (
  `post_atachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `post_attachment_title` varchar(200) DEFAULT NULL,
  `post_attachment_path` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_atachment_id`),
  KEY `fk1` (`post_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_atachment` */

/*Table structure for table `post_category` */

DROP TABLE IF EXISTS `post_category`;

CREATE TABLE `post_category` (
  `post_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_category_id`),
  KEY `post_id` (`post_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `post_category_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_category` */

/*Table structure for table `post_comment` */

DROP TABLE IF EXISTS `post_comment`;

CREATE TABLE `post_comment` (
  `post_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `post_comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_comment_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_comment` */

insert  into `post_comment`(`post_comment_id`,`post_id`,`user_id`,`comment`,`is_active`,`created_at`) values 
(14,25,54,'Great','Active','2024-05-13 10:03:15'),
(15,21,54,'lala',NULL,'2024-05-27 10:55:02'),
(16,21,54,'hello',NULL,'2024-05-27 10:55:45'),
(17,28,54,'Fantastic',NULL,'2024-05-27 10:58:05');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_type` varchar(50) NOT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `role` */

insert  into `role`(`role_id`,`role_type`,`is_active`) values 
(1,'admin','Active'),
(2,'user','Active');

/*Table structure for table `setting` */

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `setting_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`setting_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `setting_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `setting` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` text NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `user_image` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `is_approved` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`user_id`,`role_id`,`first_name`,`last_name`,`email`,`password`,`gender`,`date_of_birth`,`user_image`,`address`,`is_approved`,`is_active`,`created_at`,`updated_at`) values 
(53,1,'Jawahar','Lal','jawahar@gmail.com','lal123','Male','2024-06-05','1716743581_Untitled.png',' Hyderabad ','Approved','Active','2024-05-26 22:18:45','2024-05-26 22:18:45'),
(54,2,'Dileep','Kumar','abc@gmail.com','lal123','Male','2024-05-09','1716743888_Untitled.png','Sindh','Approved','Active','2024-05-26 22:19:00','2024-05-26 22:19:00'),
(57,2,'Nisar','Khan','khan@gmail.com','khan123','Male','2024-04-30','1716785707_Untitled.png',' jamshoro','Approved','InActive','2024-05-27 09:58:21',NULL),
(58,2,'Lal','Lakhani','lakhani@gmail.com','lal123','Male','2024-05-08','1716786727_Untitled.png',' Hyd','Approved','Active','2024-05-27 10:12:08',NULL),
(59,2,'Adil','Hmza','hmza@gmail.com','hmz123','Male','2024-05-23','1716786889_Untitled.png',' lal','Approved','Active','2024-05-27 10:14:49',NULL),
(60,2,'lal','lal','lal@gmail.com','lalal','Male','2024-05-01','1716787015_Untitled.png',' lal','Approved','Active','2024-05-27 10:16:55',NULL),
(61,2,'hello','hy','lal@gmail.com','lal','Male','2024-05-22','1716787191_Untitled.png','alla','Approved','Active','2024-05-27 10:19:51',NULL),
(62,2,'Jawahar','Lal','jawahar@gmail.com','lallala','Male','2024-04-29','1716787247_Untitled.png','Karachi','Approved','Active','2024-05-27 10:22:07','2024-05-27 10:22:07');

/*Table structure for table `user_feedback` */

DROP TABLE IF EXISTS `user_feedback`;

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user_feedback` */

insert  into `user_feedback`(`feedback_id`,`user_id`,`user_name`,`user_email`,`feedback`,`created_at`) values 
(3,53,'JawaharLAl','jawahar@gmail.com','Good','2024-05-14 10:01:55');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
