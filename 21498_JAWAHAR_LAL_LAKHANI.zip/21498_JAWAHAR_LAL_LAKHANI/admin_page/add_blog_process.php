<?php
require_once("require/db_connection.php");

// Adding a new blog
if (isset($_POST['add_blog'])) {
    $title = $_POST['title'];
    $post_per_page = $_POST['post_per_page'];
    $tmp_name = $_FILES['blog_image']['tmp_name'];
    $file_name = $_FILES['blog_image']['name'];
    $path = time() . "_" . $file_name;

    $folder = "Blog_bg_image";
    if (!is_dir($folder)) {
        mkdir($folder) or die("Could Not Create Directory $folder");
    }

    if (move_uploaded_file($tmp_name, $folder . "/" . $path)) {
        $sql = "INSERT INTO blog (blog_title, post_per_page, blog_background_image, blog_status) 
                VALUES ('$title', '$post_per_page', '$path', 1)";

        if ($connection->query($sql) === TRUE) {
            header("Location: add_blogs.php?msg=Blog Added successfully!&color=lightgreen");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    } else {
        header("Location: add_blogs.php?msg=File Not Uploaded Blog not added!&color=lightpink");
        exit();
    }
}


?>
