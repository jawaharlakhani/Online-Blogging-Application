<?php
require_once("require/db_connection.php");

if (isset($_POST['add_category'])) {
 $title = $_POST['title'];
 $Description = $_POST['description'];

 $sql = "INSERT INTO category(category_title,category_description,category_status) VALUES('$title','$Description',1 )";
 if ($connection->query($sql)=== True) {
 	header("Location: add_categories.php?msg=Category added successfully!&color=lightgreen");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    } else {
        header("Location: add_categories.php?msg= NOt added!&color=lightpink");
    }
    exit();




?>