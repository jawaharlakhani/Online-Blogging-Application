<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Post</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Font Awesome CSS -->
    <style type="text/css">
        .navbar {
            background-color: #6DC5D1;
            padding: 1px;
        }

        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-light sticky-top" style="border-bottom:1px dotted;">
    <div class="container-fluid">
        <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
            <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
            Jawahar Lal
        </a>
        <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#loginModal">LogOut</button>
    </div>
</nav>
<!---navbar-->

<div class="container-fluid">
    <div class="row">
        <?php include_once("sidebaar.php"); ?> 
        <div class="col-md-9">
            <!-- Add Posts Section -->
            <div class="content">
                <div class="container-fluid">
                    <h2>Add Posts</h2>
                    <?php if(isset($_GET["msg"])) { ?>
                        <p style="background-color:<?php echo $_GET["color"]; ?>; padding: 15px; text-align:center; margin: 30px; border-radius: 10px;"><?php echo $_GET["msg"]; ?></p>
                    <?php } ?>
             <form action="add_post_process.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="post_title" class="form-label">Post Title</label>
                            <input type="text" class="form-control" id="post_title" name="post_title">
                        </div>
                        <div class="mb-3">
                            <label for="post_summary" class="form-label">Post Summary</label>
                            <textarea class="form-control" id="post_summary" name="post_summary" rows="5"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="post_description" class="form-label">Post Description</label>
                            <textarea class="form-control" id="post_description" name="post_description" rows="5"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="featured_image" class="form-label">Featured Image</label>
                            <input type="file" class="form-control" id="featured_image" name="featured_image">
                        </div>
                        <button type="submit" class="btn btn-primary" name="add_post">Add Post</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-------logout  model------------>
<?php require_once("logout.php");?>
<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
