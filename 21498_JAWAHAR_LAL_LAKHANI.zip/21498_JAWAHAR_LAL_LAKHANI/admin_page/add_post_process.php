<?php
require_once("require/db_connection.php");

if (isset($_POST['add_post'])) {
    $post_title = $_POST['post_title'];
    $post_summary = $_POST['post_summary'];
    $post_description = $_POST['post_description'];
    $tmp_name = $_FILES['featured_image']['tmp_name'];
    $file_name = $_FILES['featured_image']['name'];
    $path = time() . "_" . $file_name;
    
    $folder = "Post_Images";
    if (!is_dir($folder)) {
        mkdir($folder);
    }

    if (move_uploaded_file($tmp_name, $folder . "/" . $path)) {
        $sql = "INSERT INTO post (post_title, post_summary, post_description, featured_image, post_status, is_comment_allowed) 
                VALUES ('$post_title', '$post_summary', '$post_description', '$path', 1, 1)";

        if ($connection->query($sql) === TRUE) {
            header("Location: add_new_post.php?msg=Post added successfully!&color=lightgreen");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    } else {
        header("Location: add_new_post.php?msg=File not uploaded, post not added!&color=lightpink");
    }
}

if (isset($_POST['update_post'])) {
    $post_id = $_POST['post_id']; 
    $post_title = $_POST['post_title'];
    $post_summary = $_POST['post_summary'];
    $post_description = $_POST['post_description'];
    
    $tmp_name = $_FILES['featured_image']['tmp_name'];
    $file_name = $_FILES['featured_image']['name'];
    $path = "";

    $folder = "Post_Images";
    if (!is_dir($folder)) {
        mkdir($folder);
    }

    if (!empty($file_name)) {
        $path = time() . "_" . $file_name;
        move_uploaded_file($tmp_name, $folder . "/" . $path);
    }

    $sql = "UPDATE post SET 
                post_title = '$post_title', 
                post_summary = '$post_summary', 
                post_description = '$post_description'";

    if (!empty($path)) {
        $sql .= ", featured_image = '$path'";
    }

    $sql .= " WHERE post_id = '$post_id'";

    if ($connection->query($sql) === TRUE) {
        header("Location: view_all_posts.php?msg=Post updated successfully!&color=lightgreen");
    } else {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}

exit();
?>
