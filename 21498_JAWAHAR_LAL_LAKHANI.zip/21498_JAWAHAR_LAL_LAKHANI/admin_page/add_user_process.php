<?php
require_once("require/db_connection.php");

if (isset($_POST['submit'])) {
    $first_name = $_POST['firstName'];
    $last_name = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : "";
    $date_of_birth = $_POST['dob'];
    $address = $_POST['address'];
    $tmp_name = $_FILES['profile_image']['tmp_name'];
    $file_name = $_FILES['profile_image']['name'];
    $path = time() . "_" . $file_name;
    $role_id = 2;

    $folder = "Images";
    if (!is_dir($folder)) {
        mkdir($folder);
    }

    if (move_uploaded_file($tmp_name, $folder . "/" . $path)) {
        $sql = "INSERT INTO user 
                (first_name, last_name, email, password, gender, date_of_birth, address, user_image, role_id, is_active, is_approved) 
                VALUES 
                ('$first_name', '$last_name', '$email', '$password', '$gender', '$date_of_birth', '$address', '$path', '$role_id', 'Active', 'Approved')";

        if ($connection->query($sql) === TRUE) {
            header("Location: add_users.php?msg=File Uploaded and User Processed Successfully!&color=lightgreen");
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }
}
//////////////////////////////updateee code

if (isset($_POST['update'])) {
    $user_id = $_POST['user_id'];  
    $first_name = $_POST['firstName'];
    $last_name = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : "";
    $date_of_birth = $_POST['dob'];
    $address = $_POST['address'];
    $tmp_name = $_FILES['profile_image']['tmp_name'];
    $file_name = $_FILES['profile_image']['name'];
    $path = "";

    $folder = "Images";
    if (!is_dir($folder)) {
        mkdir($folder);
    }

    if (!empty($file_name)) {
        $path = time() . "_" . $file_name;
        move_uploaded_file($tmp_name, $folder . "/" . $path);
    }

    $sql = "UPDATE user SET 
                first_name = '$first_name', 
                last_name = '$last_name', 
                email = '$email', 
                password = '$password', 
                gender = '$gender', 
                date_of_birth = '$date_of_birth', 
                address = '$address', 
                is_approved = 'Approved', 
                is_active = 'Active', 
                updated_at = NOW()";

    if (!empty($path)) {
        $sql .= ", user_image = '$path'";
    }

    $sql .= " WHERE user_id = '$user_id'";

    if ($connection->query($sql) === TRUE) {
        header("Location: view_all_users.php?msg=User Updated Successfully!&color=lightgreen");
    } else {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}

exit();
?>
