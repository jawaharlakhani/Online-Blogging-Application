<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Font Awesome CSS -->
    <style type="text/css">
        .navbar {
            background-color: #6DC5D1;
            padding: 1px;
        }

        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }

        /* Circular Statistics Components */
.statistics-section {
    margin-top: 50px;
    padding: 25px;
}
h4{
    font-size: 18px;
    font-family: roboto;

}

.circle {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 150px;
    height: 150px;
    border-radius: 10px;
    color: #fff;


}

.circle span:first-child {
    font-size: 16px;

}

.circle span:last-child {
    font-size: 24px;
    font-weight: bold;

}

.card-custom {
    border: none;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.3s ease;
}

.card-custom:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.5);
}


        .bar {
            width: 100%;
            margin-bottom: 10px;
        }

        .bar-container {
            display: flex;
            align-items: center;
            padding: 5px;
            border-radius: 5px;
            background-color: #f0f0f0;
            transition: width 0.5s ease;
        }

        .bar-label {
            flex: 1;
            padding-right: 10px;
            font-weight: bold;
        }

        .bar-graph {
            flex: 5;
            height: 20px;
            background-color: #007bff;
            border-radius: 5px;
        }

        .bar-value {
            padding-left: 10px;
            color: #007bff;
        }

    .row {
    
        padding: 35px;
    }
        
    </style>
</head>

<body >

<nav class="navbar navbar-light sticky-top " style="border-bottom:1px dotted;">
    <div class="container-fluid">
        <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
            <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
             Admin:-Jawahar Lal
        </a>
        <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#loginModal">LogOut</button>
    </div>
</nav>
<!---navbar-->

<div class="container-fluid ">
    <div class="row">
        <?php include_once("sidebaar.php"); ?> 
        <div class="col-md-9">
            <?php require_once('dashboard.php');?>
        </div> 
    </div>
</div>

<!-- Footer -->
   <?php require_once("footer.php");?>
<?php require_once("logout.php");?>

<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
