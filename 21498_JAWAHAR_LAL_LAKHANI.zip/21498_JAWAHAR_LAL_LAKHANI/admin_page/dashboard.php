<?php require_once("require/db_connection.php");?>










<div class="container">
    <div class="row mt-4">
        <!-- Weekly Blog Views, New Users, Visitors -->
        <div class="col-lg-4 mb-4">
            <div class="card card-custom">
                <div class="card-body">
                    <h5 class="card-title">Active Users</h5>
                    <a class="card-text text-center" href="active_users.php" >Active User12++</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card card-custom">
                <div class="card-body">
                    <h5 class="card-title">Pending Users</h5>
                    <a href="pending_users.php">Pending User++</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card card-custom">
                <div class="card-body">
                    <h5 class="card-title">Inactive Users</h5>
                    <a class="card-text" href="Inactive_users.php">Inactive User++</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Blog Statistics -->
    <div class="row justify-content-center">
        <div class="col-md-3 mb-4">
            <div class="circle" style="background-color: #ff6b6b;">
                <span>Total Posts:</span>
                <span>1000+</span>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="circle" style="background-color: #48dbfb;">
                <span>Total Comments:</span>
                <span>2000+</span>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="circle" style="background-color: #1dd1a1;">
                <span>Total Views:</span>
                <span>2M+</span>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="circle" style="background-color: olive;">
                <span>Total Users:</span>
                <span>5M+</span>
            </div>
        </div>
    </div>

          
    













