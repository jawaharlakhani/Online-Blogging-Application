          <div class="container">
   <!---------feedback-->
                 <h2 class="text-center">Feedback</h2>
                   <form action="feedback_process.php" method="POST">
                  <div class="col-md-6">
                    <div class="input-group form-outline" data-mdb-input-init>
                      <label for="validationCustomUsername" class="form-label">Username</label>
                      <span class="input-group-text" id="inputGroupPrepend">@</span>
                      <input type="text" class="form-control" id="Username" name="Username" />
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-outline" data-mdb-input-init>
                      <label for="feedback" class="form-label">feedback</label>
                      <textarea type="text" class="form-control" id="feedback" name="feedback"></textarea>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="form-check">
                      <label class="email" for="email">Email</label>
                      <input class="email" type="email" value="" id="email"  />
                    </div>
                  </div>
                  <div class="col-12">
                    <button class="btn btn-primary" type="submit" name="submit" >Submit form</button>
                  </div>
                </form>
           </div>