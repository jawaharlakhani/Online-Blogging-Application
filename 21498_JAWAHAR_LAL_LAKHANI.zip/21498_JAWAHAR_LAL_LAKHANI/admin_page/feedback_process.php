<?php
require_once("require/db_connection.php");

if (isset($_POST['submit'])) {
    if (isset($_POST['username']) && isset($_POST['feedback']) && isset($_POST['email'])) {
        $username = $_POST['username'];
        $feedback = $_POST['feedback'];
        $email = $_POST['email'];

        $sql = "INSERT INTO user_feedback (user_name,user_email,feedback) VALUES ('$username','$email','$feedback')";

        if ($connection->query($sql) === TRUE) {
            echo "<h2>Feedback Received</h2>";
            echo "<p>Username: $username</p>";
            echo "<p>Feedback: $feedback</p>";
            echo "<p>Email: $email</p>";
            echo "<p>Data inserted into database successfully.</p>";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }
}

$connection->close();
?>
