 <footer class="container-fluid text-center py-4" style="background-image: url('https://images.unsplash.com/photo-1510857817970-2a7060a55c8c?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YmxvZ3xlbnwwfHwwfHw%3D'); background-size: cover; color: black; ">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <p>Phone: +923467207546</p>
                <p>Email: jawaharlakhanii@gmail.com</p>
            </div>
            <div class="col-md-4">
                <h5>Follow Us</h5>
                <a href="#"><img src="https://img.icons8.com/color/48/000000/facebook-circled--v1.png"/></a>
                <a href="#"><img src="https://img.icons8.com/color/48/000000/instagram-new--v1.png"/></a>
                <a href="#"><img src="https://img.icons8.com/color/48/000000/twitter--v2.png"/></a>
            </div>
            <div class="col-md-4">
                <h5>Address</h5>
                <p>Hyderabad, Main Road, New City</p>
                <p>Pakistan</p>
            </div>
        </div>
        <hr>
        <p>&copy; || 2024 My Blogz ||</p>
    </div>
</footer>