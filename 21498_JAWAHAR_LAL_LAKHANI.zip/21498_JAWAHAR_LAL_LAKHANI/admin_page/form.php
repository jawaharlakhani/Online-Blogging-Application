<?php  

if (isset($_POST['submit'])) {
  echo "<pre>";
  print_r($_POST);
  echo "</pre>";
}




?>