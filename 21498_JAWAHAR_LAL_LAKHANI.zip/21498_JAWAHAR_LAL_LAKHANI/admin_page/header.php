<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blogging</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Font Awesome CSS -->
    
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <style>
        .navbar {
            background-color: #6DC5D1;
            padding:1px;
        }
        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }
        .content-container {
            position: relative;
            text-align: center;
            color: black;
            padding: 10px;
            z-index: 1; 
        }
        .modal-form .modal-body {
            background-color: skyblue;
        }
        /* Modal form input fields */
        .modal-form input[type="text"],
        .modal-form input[type="email"],
        .modal-form input[type="password"] {
            background-color: #FFF;
        }
        /* Our Team section heading */
        .heading-with-shadow {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .modal-form .modal-content {
    background-color: #87CEEB; 
}
 .image-container {
      padding: 70px;
    }
    .image-container img {
      width: 100px;
      height: 100px;
      display: block;
      margin: 0 auto;
      border: 1px solid black;
      border-radius: 50%;
    }
    .image-container p {
      margin-top: 10px;
    }
    .image-container img:hover {
      transform: scale(1.1);

    }
      /* Customize slider container */
    .slider-container {
        width: 80%;
        margin: 0 auto;
        overflow: hidden;
    }
    /* Customize slider item */
    .slider {
        display: flex;
        animation: slide 10s infinite;
    }
    .slider {
    transition: transform 0.3s ease-in-out;
}
    .blog-post {
        flex: 0 0 auto;
        width: 100%;
        padding: 2px;
        box-sizing: border-box;
        border: 1px solid #ccc;

    }

    /* Keyframe animation */
    @keyframes slide {
        0% {
            transform: translateX(0);
        }
        25% {
            transform: translateX(-100%);
        }
        50% {
            transform: translateX(-200%);
        }
        75% {
            transform: translateX(-300%);
        }
        100% {
            transform: translateX(0);
        }
    }
     .slider:hover {
        animation-play-state: paused;
    }
         .read-more-btn {
            background-color: skyblue;
            color: black;
            border: none;
            padding: 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            cursor: pointer;
            border-radius: 5px;
        }
        .read-more-btn:hover{
            background-color: #03AED2;

        }
        /* Center align the button */
        .read-more-btn-container {
            text-align: center;
        }

         .card-img-top {
        height: 200px; 
        width: 100%;
        object-fit: cover; 
    }
    </style>
</head>
<body>



 <nav class="navbar navbar-light sticky-top " style="border-bottom:1px dotted;">
        <div class="container-fluid">
            <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
                <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
                MY BLOGZ
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active text-dark" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark" href="#">About</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link text-dark" href="#">Service</a>
                    </li>
                </ul>
                <a class="btn btn-outline-light" href="register.php" target="_blank">Register</a>
                <a class="btn btn-outline-light" href="login.php" target="_blank">Login</a>
            </div>
        </div>
    </nav>