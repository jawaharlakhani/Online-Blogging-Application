<?php
ob_start();
require_once("require/db_connection.php");
require_once("header.php");
?>


<div class="container">
	<div class="row mt-5" style="background-color: lightgreen;">
		<h1 class="text-center"  style="color:black;"> Rejected Users</h1>
	</div>

    <div class="row mt-5 border border-primary bg-light">
      <table  class="table display"  id="table_id">
        <thead>
          <tr>
            <th>User ID</th>
            <th>First-Name</th>
            <th>Last-Name</th>

            <th>Email</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>


<?php
            $query = "SELECT user_id, first_name,last_name ,email FROM user where is_active = 'InActive'";
            $result = mysqli_query($connection,$query);

            if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
?>


        <tr>
            <td><?= $row["user_id"]?></td>
            <td><?= $row["first_name"]?></td>
            <td><?= $row["last_name"]?></td>
            <td><?= $row["email"]?></td>
            <td><a href="?active=<?= $row["user_id"];?>" class="btn btn-success">Active</a></td>
            <!-- <td><a href="?reject=<?= $row["user_id"];?>" class="btn btn-danger">Reject</a></td> -->
        </tr>
<?php
             }
            }
?>

<?php 
            if (isset($_REQUEST['active'])) {
            $query = "UPDATE user SET  is_active = 'Active' WHERE user_id ='".$_REQUEST['active']."'";
            $result = mysqli_query($connection, $query);

            if ($result) {
            header("location:inactive_users.php? message=User Activate");
             }
             else {
             header("location:inactive_users.php? message=  User Deactivate");
            ob_end_flush();
            exit();
            }
                }
?>

        </tbody>
      </table>
    </div>
</div>

