<?php require_once("require/db_connection.php");?>

           <!---------header---->
    <!-- Navbar -->
   <?php require_once("header.php");?>
<!------------navbar end-->
          <!---------header---->
<!---heading-->
<div class="container-fluid" style="padding: 150px; background-color: skyblue; border-bottom:1px dotted;">
    <div class="row">
         <div class="col-sm-12 text-center">
             <h2 style="border-bottom: 1px dotted; font-size:50px; font-family: Roboto;">Online Blogging Application</h2>
         </div>
    </div>
</div>
<!----heading-->



<!-----icons-->
<!---icons-->
<div class="container-fluid" style="border-bottom:1px dotted;">
  <div class="row">
    <div class="col-sm-4 image-container">
      <img src="https://assets.dryicons.com/uploads/icon/preview/12161/small_2x_0928a729-0b5e-40e1-ad01-b2d4312990f8.png" class="img-fluid rounded-circle" alt="Image 1"><br>
      <h5 class="text-center text-primary">Why My Blogz?</h5>
      <p class="text-black text-center">My Blogz offers a platform for self-expression and community.It empowers individuals to share ideas,connect with like-minded people,and foster positive change.With limitless creative possibilities and a global reach,it's the perfect space to amplify voices and make a meaningful impact.</p>
       <div class="read-more-btn-container">
          <a href="login.php" class="read-more-btn">Read More...!</a>
      </div>
    </div>
    <div class="col-sm-4 image-container">
      <img src="https://assets.dryicons.com/uploads/icon/preview/12159/small_2x_80bb0a23-da06-4ebf-a121-c122d7cc132e.png" class="img-fluid rounded-circle" alt="Image 2"><br>
      <h5 class="text-center text-primary">Insightful Analytics</h5>
      <p class="text-black text-center">Data Insights offers a centralized platform for analyzing data, visualizing key metrics, and identifying trends. With intuitive navigation and customizable features, it empowers users to make informed decisions based on data-driven insights.</p>
       <div class="read-more-btn-container">
          <a href="login.php" class="read-more-btn">Read More...!</a>
      </div>
    </div>
    <div class="col-sm-4 image-container">
      <img src="https://assets.dryicons.com/uploads/icon/preview/12155/small_2x_d6f7d547-d285-4afb-9053-b45e2588501c.png" class="img-fluid rounded-circle" alt="Image 3"><br>
      <h5 class="text-center text-primary">Vision Statement</h5>
      <p class="text-black">The site's mission is to empower sharing of thoughts, experiences, and expertise via blogging, fostering a supportive community for connection, learning, and inspiration. It provides valuable resources for personal and professional growth.</p>
       <div class="read-more-btn-container">
          <a href="login.php" class="read-more-btn">Read More...!</a>
      </div>
    </div>
  </div>
</div>
<!---icons end-->

<!-------sliderrr------->
    
<div class="container-fluid" style="border-bottom:1px dotted;">
    <div class="row">
        <div class="col-sm-12">
            <div class="slider-container">
                <div class="slider">
                    <?php
                    $query = "SELECT * FROM blog";
                    $result = mysqli_query($connection, $query);

                    if ($result->num_rows > 0) {
                        while ($data = mysqli_fetch_assoc($result)) {
                            ?>
                            <div class="blog-post"> 
                                <h2><?php echo $data["blog_title"]; ?></h2>
                                <img src="../admin_page/Blog_bg_image/<?php echo $data["blog_background_image"]; ?>" alt="<?php echo $data["blog_title"]; ?>" width="500px" height="350px">
                            </div>
                            <?php
                        }
                    } else {
                        echo "<p class='text-center'>No blogs found.</p>";
                    }
                    ?>
                </div>
            </div> 
        </div>
    </div>
</div>
<!---slideeer end-->

    
<!-- Category Filters Section -->
<div class="container-fluid py-5" style="background-color: #85C1E9; border: 1px dotted;">
   <div class="container">
    <h2 class="text-center mb-4">Blog Categories</h2>
    <div class="row">
        <?php
        $query = "SELECT * FROM blog";
        $result = mysqli_query($connection, $query);

        if ($result->num_rows > 0) {
            while ($data = mysqli_fetch_assoc($result)) {
                ?>
                <div class="col-md-3">
                    <div class="card mb-4">
                        <img src="../admin_page/Blog_bg_image/<?php echo $data["blog_background_image"]; ?>" class="card-img-top" alt="Blog Image">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $data["blog_title"]; ?></h5>
                        <a href="login.php" class="btn btn-primary">Read More</a>

                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p class='text-center'>No blogs found.</p>";
        }
        ?>
    </div>
</div>

</div>

<!-- Related Posts Section -->
<div class="container-fluid py-5" style="background-color: #5DADE2;">
    <div class="container">
        <h2 class="text-center mb-4">Related Posts</h2>
        <div class="row">
            <?php
            $query = "SELECT * FROM post ORDER BY RAND() LIMIT 3";
            $result = mysqli_query($connection, $query);

            if ($result->num_rows > 0) {
                while ($data = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <img src="../admin_page/Post_Images/<?php echo $data["featured_image"]; ?>" class="card-img-top" alt="<?php echo $data["post_title"]; ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $data["post_title"]; ?></h5>
                                <p class="card-text"><?php echo substr($data["post_description"], 0, 100); ?>...</p> 
                                <a href="login.php" class="btn btn-primary">Read More</a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p class='text-center'>No related posts found.</p>";
            }
            ?>
        </div>
    </div>
</div>







<!-- Blog Section -->
<section id="blog" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <?php
                // Fetch the latest blog post
                $query = "SELECT * FROM blog ORDER BY created_at DESC LIMIT 1";
                $result = mysqli_query($connection, $query);

                if ($result->num_rows > 0) {
                    $data = mysqli_fetch_assoc($result);
                    ?>
                    <div class="card mb-4">
                        <img src="../admin_page/Blog_bg_image/<?php echo $data["blog_background_image"]; ?>" class="card-img-top" alt="<?php echo $data["blog_title"]; ?>">
                        <div class="card-body">
                            <h2 class="card-title"><?php echo $data["blog_title"]; ?></h2>
                            <a href="login.php" class="btn btn-primary">Read More &rarr;</a>
                        </div>
                        <div class="card-footer text-muted">
                            Posted on <?php echo date('F j, Y', strtotime($data["created_at"])); ?> by Jawahar Lal
                        </div>
                    </div>
                    <?php
                } else {
                    echo "<p class='text-center'>No blog posts found.</p>";
                }
                ?>
            </div>
            <div class="col-lg-4">
                <?php
                // Fetch related blog posts
                $query = "SELECT * FROM blog ORDER BY RAND() LIMIT 1";
                $result = mysqli_query($connection, $query);

                if ($result->num_rows > 0) {
                    while ($data = mysqli_fetch_assoc($result)) {
                        ?>
                        <div class="card mb-4">
                            <img src="../admin_page/Blog_bg_image/<?php echo $data["blog_background_image"]; ?>" class="card-img-top" alt="<?php echo $data["blog_title"]; ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $data["blog_title"]; ?></h5>
                               
                                <a href="login.php" class="btn btn-primary">Read More &rarr;</a>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "<p class='text-center'>No related posts found.</p>";
                }
                ?>
            </div>
        </div>
    </div>
</section>


<!--------newwwwletter------>
<div class="container-fluid my-5">
    <div class="row justify-content-center">
        <!-- Newsletter Signup -->
        <div class="col-md-6" style="border-bottom: 1px dotted;">
            <div class="container">
                <h2 class="text-center mb-4">Subscribe to Our Newsletter</h2>
                <p class="text-center">Get exclusive content, updates, and promotions straight to your inbox.</p>
                <form action="#" method="post" class="input-group mb-3">
                    <input type="email" class="form-control" placeholder="Enter your email address" aria-label="Email" aria-describedby="button-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit" id="button-addon2">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- End Newsletter Signup -->
<div class="col-md-6" style="border-bottom: 1px dotted;">
            <?php 
            require_once("feedback.php");?>
        </div>
    </div>
</div>


    
    <!-- Footer -->
   <?php require_once("footer.php");?>
<!-- End Footer -->
</div>
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

