<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <style>
        .background-image {
            background-image: url('https://images.unsplash.com/photo-1604145195376-e2c8195adf29?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwzMHx8fGVufDB8fHx8fA%3D%3D');
            background-size: cover;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            filter: blur(10px);
            z-index: -1;
        }
        .navbar {
            background-color: #6DC5D1;
            padding:1px;
        }
        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }
    </style>
</head>
<body>

    <!-------Navbar---->    
     <nav class="navbar navbar-light sticky-top " style="border-bottom:1px dotted;">
        <div class="container-fluid">
            <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
                <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
                MY BLOGZ
            </a>
        </div>
    </nav>
<!-----------------end------>

    <div class="background-image"></div>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        Login
                    </div>
                      <?php
                         if(isset($_GET["message"]))
                                       {
                        ?>
                <p style="background-color:<?php echo $_GET["color"]; ?>; padding: 15px; text-align:center; margin: 30px; border-radius: 10px;"><?php echo $_GET["message"]; ?></p>
                       <?php
                       }
                       ?>
                    <div class="card-body">
                  
                        <form action="login_process.php" method="POST">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" >
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password">
                            </div>
                            <button type="submit" class="btn btn-primary d-grid w-100" name="login">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
