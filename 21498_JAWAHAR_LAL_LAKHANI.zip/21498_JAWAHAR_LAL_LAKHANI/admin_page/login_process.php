<?php
require_once('require/db_connection.php');
session_start();

if (isset($_POST['login'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];

    if (isset($email) && isset($password) && !empty($email) && !empty($password)) {

        $sql = "SELECT * FROM user WHERE email = '$email' AND password = '$password'";
        $result = mysqli_query($connection, $sql);

        if ($result && $result->num_rows > 0) {
            $row = mysqli_fetch_assoc($result);

            $_SESSION['user'] = $row;

            // var_dump($_SESSION);
            // die();
            if ($_SESSION['user']['role_id'] == 1) {
                //session add in this //

                header("location:admin.php");
            } elseif ($_SESSION['user']['role_id'] == 2) {
                ///session add in this//
    
                header("location:../user_page/user_page.php");
            } else {
                header("location: admin.php?message=login successfully!&color=lightgreen");
            }
        } else {
            header("location: login.php?message=Invalid email or password!&color=lightred");
        }

        mysqli_close($connection);

    } else {
        header("location: login.php?message=Please enter both email and password!&color=lightpink");
    }
}
?>
