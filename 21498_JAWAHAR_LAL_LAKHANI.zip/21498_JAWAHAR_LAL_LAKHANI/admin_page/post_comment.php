<?php
require_once("require/db_connection.php");

session_start();
$user_id = $_SESSION['user']['user_id'];
// var_dump($_SESSION);
// die();
if (isset($_POST['comment']) && isset($_POST['post_id'])) {
    $post_id = $_POST['post_id'];
    $comment = $_POST['comment'];
// var_dump($_POST);
// die();
    $user_query = "SELECT * FROM user WHERE user_id = '$user_id'";
    $user_result = mysqli_query($connection, $user_query);

    if (mysqli_num_rows($user_result) > 0) {
        $query = "INSERT INTO post_comment (post_id, user_id, comment, created_at) VALUES ('$post_id', '$user_id', '$comment', NOW())";

        if (mysqli_query($connection, $query)) {
            header("Location: ../user_page/post_1.php?post_id=$post_id&msg=Comment added successfully!&color=lightgreen");
            exit();
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($connection);
        }
    } else {
        echo "Error: User does not exist.";
    }
} else {
    echo "Error: Post ID or Comment is missing.";
}
?>
