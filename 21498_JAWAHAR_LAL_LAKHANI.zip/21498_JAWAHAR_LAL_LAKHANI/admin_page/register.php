<?php   
require_once("register_serverside.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <style>
        .navbar {
            background-color: #6DC5D1;
            padding:1px;
        }
        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }
        .container{
            width: 60%;
            margin-bottom: 20px;

        }
        form {
            border-color: black;
        }
        .form-control {
            border-color: black;
        }
        span{
            color: red;
        }
    </style>
        <script type="text/javascript" src="register_client_validate.js"></script>
</head>
<body>
           <!---------header---->
    <!-- Navbar -->
     <nav class="navbar navbar-light sticky-top " style="border-bottom:1px dotted;">
        <div class="container-fluid">
            <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
                <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
                MY BLOGZ
            </a>
        </div>
    </nav>
    
<!-- Modal for Sign Up -->
<div class="container">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title " style="text-align: center;" >Sign Up</h5>
            </div>
             <?php
                         if(isset($_GET["msg"]))
                                       {
                        ?>
                <p style="background-color:<?php echo $_GET["color"]; ?>; padding: 15px; text-align:center; margin: 30px; border-radius: 10px;"><?php echo $_GET["msg"]; ?></p>
                       <?php
                       }
                       ?>
              <p><span>Note:   Fill The Form</span></p>
            <div class="modal-body">
                <!-- Registration form -->
                <form method="POST" action="register_process.php" enctype="multipart/form-data" onsubmit="return validateForm()">
                    <div class="mb-3">
                        <label for="firstName" class="form-label">First Name:<span>*</span></label>
                        <input type="text" class="form-control" id="firstName" name="firstName" value="<?= $first_name??""; ?>">
                        <span id="first_msg"><?=  $first_msg??"";  ?></span>
                    </div>
                    <div class="mb-3">
                        <label for="lastName" class="form-label">Last Name:<span>*</span></label>
                        <input type="text" class="form-control" id="lastName" name="lastName" value="<?= $last_name??""; ?>">
                        <span id="last_msg"><?=  $last_msg??"";  ?></span>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email address :<span>*</span></label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= $email??""; ?>">
                        <span id="email_msg"><?=  $email_msg??"";  ?></span>
                        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password: <span>*</span></label>
                        <input type="password" class="form-control" id="Password" name="password" value="<?= $password??""; ?>">
                        <span id="password_msg"><?=  $password_msg??"";  ?></span>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Gender <span>*</span></label>
                        <div class="form-check">
                            <input type="radio" name="gender" value="Male" <?= (isset($gender) && $gender == "Male")?'checked':'';  ?> /> Male
                            <input type="radio" name="gender" value="Female" <?= (isset($gender) && $gender == "Female")?'checked':'';  ?> /> Female
                            <span id="gender_msg"><?=  $gender_msg??"";  ?></span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="dob" class="form-label">Date of Birth :<span>*</span></label>
                        <input type="date" class="form-control" id="dob" name="dob" value="<?= $dob ?? ''; ?>"/>
                        <span id="dob_msg"><?=  $dob_msg??"";  ?></span>
                    </div>
                    <div class="mb-3">
                        <label for="userImage" class="form-label">User Image :<span>*</span></label>
                        <input type="file" class="form-control" id="profile_image" name="profile_image" value="<? $image??''; ?> "/>
                        <span id="image_msg"> <?= $image_msg??"";?></span>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address :<span>*</span></label>
                        <textarea class="form-control" id="address" rows="3" name="address" value="<?= $address ?? ''; ?>"> </textarea>
                         <span id="address_msg"><?=  $address_msg??"";  ?></span>

                    </div>
                    <button type="submit" class="btn btn-primary d-block w-100" name="submit">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<?php require_once("footer.php");?>
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

