function validateForm() {
    var flag = true;

    /* Patterns */
    var alpha_pattern = /^[A-Z]{1}[a-z]{2,}$/;
    var email_pattern = /^[a-z]+\d*[@]{1}[a-z]+[.]{1}(com|net){1}$/;

    /* Target input fields */
    var first_name = document.querySelector("#firstName").value;
    var last_name = document.querySelector("#lastName").value;
    var email = document.querySelector("#email").value;
    var password = document.querySelector("#Password").value;
    var gender = document.querySelector("input[type='radio']:checked");
    var dob = document.querySelector("#dob").value;
    var address = document.querySelector("#address").value;


    /* Target error message span */
    var first_msg = document.querySelector("#first_msg");
    var last_msg = document.querySelector("#last_msg");
    var email_msg = document.querySelector("#email_msg");
    var password_msg = document.querySelector("#password_msg");
    var gender_msg = document.querySelector("#gender_msg");
    var dob_msg = document.querySelector("#dob_msg");
    var address_msg = document.querySelector("#address_msg");

    /* First Name validation */
    if (first_name === "") {
        flag = false;
        first_msg.innerHTML = "Field Required..!";
    } else {
        first_msg.innerHTML = "";
        if (alpha_pattern.test(first_name) === false) {
            flag = false;
            first_msg.innerHTML = "First Name must be Jawahar| Ali | kanya |saba etc..!";
        }
    }

    /* Last Name validation */
    if (last_name === "") {
       flag = false;
        last_msg.innerHTML = "Field Required..!";
    } else {
        last_msg.innerHTML = "";
        if (alpha_pattern.test(last_name) === false) {
            flag = false;
            last_msg.innerHTML = "Last Name must be Lal | hamza etc..!";
        }
    }

    /* Email validation */
    if (email === "") {
        flag = false;
        email_msg.innerHTML = "Field Required..!";
    } else {
        email_msg.innerHTML = "";
        if (email_pattern.test(email) === false) {
            flag = false;
            email_msg.innerHTML = "Email must be like jawahar@gmail.com|net lal@gmail.com etc..!";
        }
    }

    /* Password validation */
    if (password === "") {
        flag = false;
        password_msg.innerHTML = "Field Required..!";
    } else {
        password_msg.innerHTML = " Password  must be like jablu123456";
    }

    /* Gender validation */
    if (!gender) {
        flag = false;
        gender_msg.innerHTML = "Field Required..!";
    } else {
        gender_msg.innerHTML = "";
    }

    /* Date of Birth validation */
    if (dob === "") {
        flag = false;
        dob_msg.innerHTML = "Field Required..!";
    } else {
        dob_msg.innerHTML = "";
    }

    /* Address validation */
    if (address === "") {
        flag = false;
        address_msg.innerHTML = "Field Required..!";
    } else {
        address_msg.innerHTML = "";
    }


    if (flag === true) {
        return true;
    } else {
        return false;
    }
}
