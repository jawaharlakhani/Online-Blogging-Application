<?php
require_once("require/db_connection.php"); 
require("fpdf/fpdf.php");  


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

if (isset($_POST['submit'])) {
    // Retrieve form data
    $first_name = $_POST['firstName'];
    $last_name = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : "";
    $date_of_birth = $_POST['dob'];
    $address = $_POST['address'];
    $tmp_name = $_FILES['profile_image']['tmp_name'];
    $file_name = $_FILES['profile_image']['name'];
    $path = time() . "_" . $file_name;
    $role_id = 2;

    $folder = "Images";
    if (!is_dir($folder)) {
        if (!mkdir($folder)) {
            echo "Could Not Create Directory $folder";
            exit();
        }
    }

    if (move_uploaded_file($tmp_name, $folder . "/" . $path)) {
        // Insert data into the database
        $sql = "INSERT INTO user (first_name, last_name, email, password, gender, date_of_birth, address, user_image, role_id) 
                VALUES ('$first_name', '$last_name', '$email', '$password', '$gender', '$date_of_birth', '$address', '$path', '$role_id')";

        if ($connection->query($sql) === TRUE) {
            // Send email
            $mail = new PHPMailer;
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';  
            $mail->SMTPAuth = true;
            $mail->Username = 'jawaharlakhanii@gmail.com'; 
            $mail->Password = 'cmyvmdfrbjctawqy'; 
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;
            $mail->setFrom('jawaharlakhanii@gmail.com', 'Jawahar Lal');
            $mail->addAddress($email, $first_name . ' ' . $last_name);

            $mail->isHTML(true);

            $mail->Subject = 'Registration Successful';
            $mail->Body    = '<p>Dear ' . $first_name . ',</p><p>Thank you for registering. Your registration was successful.</p>';

            if ($mail->send()) {
                $pdf = new FPDF();
                $pdf->AddPage();
                $pdf->SetFont('Arial', 'B', 16);
                $pdf->Cell(0, 10, 'User Registration Details', 0, 1, 'C');
                $pdf->SetFont('Arial', '', 12);
                $pdf->Cell(0, 10, 'First Name: ' . $first_name, 0, 1);
                $pdf->Cell(0, 10, 'Last Name: ' . $last_name, 0, 1);
                $pdf->Cell(0, 10, 'Email: ' . $email, 0, 1);
                $pdf->Cell(0, 10, 'Gender: ' . $gender, 0, 1);
                $pdf->Cell(0, 10, 'Date of Birth: ' . $date_of_birth, 0, 1);
                $pdf->Cell(0, 10, 'Address: ' . $address, 0, 1);
                $pdf->Image($folder . '/' . $path, 10, $pdf->GetY(), 33.78);
                $pdf_path = $folder . '/' . $email . '_registration_details.pdf';
                $pdf->Output($pdf_path, 'F');

                header("Location: register.php?msg=File Uploaded, User Registered, Email Sent, and PDF Generated Successfully!&color=lightgreen");
            } else {
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            }
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    } else {
        header("Location: register.php?msg=File Upload Failed!&color=lightpink");
    }
}

exit();
?>
