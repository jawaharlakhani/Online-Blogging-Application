<?php
if(isset($_POST['submit'])){
    extract($_POST);
    $flag = true;

    /* Define validation patterns */
    $alpha_pattern = "/^[A-Z]{1}[a-z]{2,}$/";
    $email_pattern = "/^[a-z]+\d*[@]{1}[a-z]+[.]{1}(com|net){1}$/";
    $password_pattern = "/^.{6,}$/"; 
    $phone_number_pattern = "/^\d{4}-\d{7}$/"; 
    $address_pattern = "/^.+$/"; 
    $dob_pattern = "/^\d{4}-\d{2}-\d{2}$/"; 

    /* Initialize error messages */
    $first_msg = null;
    $last_msg = null;
    $email_msg = null;
    $password_msg = null;
    $phone_number_msg = null;
    $cnic_msg = null;
    $address_msg = null;
    $gender_msg = null;
    $dob_msg = null;

    /* Validate each field */
    /*------------------------------*/
    if($firstName === ""){
        $flag = false;
        $first_msg = "Field Required ..!";
    }else{
        $first_msg = "";
        if(!(preg_match($alpha_pattern, $firstName))){
            $flag = false;
            $first_msg = "";
        }
    }

    /*------------------------------*/
    /*---------------------------------*/   
    if($lastName === ""){
        $flag = false;
        $last_msg = "Field Required..!";
    }else{ 
        $last_msg ="";
        if(!(preg_match($alpha_pattern, $lastName))){
            $flag = false;
            $last_msg = "";
        }
    }
    /*---------------------------------*/

    /*---------------------------------*/    
    if($email === ""){
        $flag = false;
        $email_msg = "Field Required..!";

    }else{
        $email_msg = "";
        if(!(preg_match($email_pattern, $email))){
            $flag = false;
            $email_msg = "";
                
        }

    }
    /*---------------------------------*/

    /*-------------------------------------------*/
    if($address===""){
        $flag = false;
        $address_msg = "Field Required..!";
    }else{
        $address_msg ="";
        if(!preg_match($address_pattern, $address)){
            $flag = false;
            $address_msg = "";
        }
    }
    /*-----------------------------------*/

    /*-----------------------------------*/
    if(!isset($gender) || $gender===""){
        $flag = false;
        $gender_msg = "Field Required..!";
    }
    /*-----------------------------------*/

    if($dob===""){
        $flag = false;
        $dob_msg = "Field Required..!";
    }else{
        $dob_msg ="";
        if(!preg_match($dob_pattern, $dob)){
            $flag = false;
            $dob_msg = "";
        }
    }

    if($flag === true){
        echo "<h1>Form Validated Successfully..!</h1>";
        showData($_POST);
    }
}

function showData($data){
    extract($data);
    ?>
    <center>
        <h1>Form Validated Successfully..!</h1>
        <table border="2px">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= $firstName; ?></td>
                    <td><?= $lastName; ?></td>
                    <td><?= $email; ?></td>
                    <td><?= $password; ?></td>
                    <td><?= $gender; ?></td>
                    <td><?= $dob; ?></td>
                    <td><?= $address; ?></td>
                </tr>
            </tbody>
        </table>
    </center>
    <?php
    die; 
}
?>
