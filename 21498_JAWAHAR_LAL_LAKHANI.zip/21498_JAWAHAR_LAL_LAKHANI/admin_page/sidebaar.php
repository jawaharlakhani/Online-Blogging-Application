<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Slider</title>
    <style type="text/css"> .sidebar {
            height: 100%;
            min-width: 200px;
            width:auto; 
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #7AB2B2;
            overflow-x: hidden;
            padding-top: 50px;
        }

        .sidebar a {
            padding: 15px 20px;
            text-decoration: none;
            font-size: 18px;
            font-family: roboto;
            color: black; 
            display: block;
            transition: all 0.3s ease; 
        }

        .sidebar a:hover {
            background-color:#80BCBD; 
            color: #fff; 
        }

        .sidebar .fa {
            margin-right: 10px;
        }</style>
</head>
<body>
    <div class="col-md-3">
    <div class="sidebar">
        <a href="admin.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="add_users.php"><i class="fas fa-users"></i> Add Users</a>
        <a href="add_new_post.php"><i class="fas fa-plus-square"></i> Add New Posts</a>
        <a href="add_categories.php"><i class="fas fa-layer-group"></i> Add Categories</a>
        <a href="view_all_categories.php"><i class="fas fa-list-alt"></i> View all Categories</a>
        <a href="add_blogs.php"><i class="fas fa-pen"></i> Add Blogs</a>
        <a href="view_all_users.php"><i class="fas fa-users"></i> View all Users</a>
        <a href="view_all_comments.php"><i class="fas fa-comments"></i> View all Comments</a>
        <a href="view_all_blogs.php"><i class="fas fa-blog"></i> View all Blogs</a>
        <a href="view_all_posts.php"><i class="fas fa-poll"></i> View all Post</a>
        <a href="view_all_feedback.php"><i class="fas fa-comment-alt"></i> View all Feedback</a>
    </div>
</div>


</body>
</html>