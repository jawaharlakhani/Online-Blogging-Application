<?php
require_once("require/db_connection.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Users</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

     <script type="text/javascript" src="jquery.min.js" ></script>

    <!-- Font Awesome CSS -->
    <style type="text/css">
        .navbar {
            background-color: #6DC5D1;
            padding: 1px;
        }

        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }

        .scrollable-table {
            max-height: 300px; 
            overflow-y: auto;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-light sticky-top " style="border-bottom:1px dotted;">
    <div class="container-fluid">
        <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
            <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
            Jawahar Lal
        </a>
        <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#loginModal">LogOut</button>
    </div>
</nav>

<div class="container-fluid ">
    <div class="row">
        <?php require_once("sidebaar.php"); ?> 
        <div class="col-md-9">
            <div class="content">
                <div class="container-fluid" style="padding-bottom: 50px;">
                    <h2>View All Categories</h2>
                    <!-- Wrapping table inside a div with scroll bar -->
                    <div class="scrollable-table">
                    <?php
                $query = "SELECT * FROM category";
                  $result = mysqli_query($connection, $query);
            
                     if($result->num_rows)
            {
                ?>
                        <table  id="table_id" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Category Id</th>
                                    <th>Category_title</th>
                                    <th>Category_description</th>
                                    <th>Category_Status</th>
                                    <th>Created_at</th>
                                    <th>Updated_at</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while($data = mysqli_fetch_assoc($result))
                                {
                                    ?>
                                <tr>
                                    <td> <?php echo $data["category_id"] ?></td>
                                    <td><?php echo $data["category_title"]?></td>
                                    <td><?php echo $data["category_description"]; ?></td>
                                    <td>
                                        <button class="btn btn-success">Active</button>
                                        <button class="btn btn-danger">Inactive</button>
                                    </td>
                                    <td><?php echo $data["created_at"]?></td>
                                    <td><?php echo $data["updated_at"];?></td>
                                </tr>
                                <!-- Add more rows as needed -->
                            </tbody>
                         <?php
                        }
                        ?>
                        </table>
                        <?php
            }
            else
            {
                ?>
                    <p style="color: red;">No category  Found!...</p>
                <?php
            }
        ?>
                    </div>
                </div>
            </div> 
        </div> 
    </div>
</div>

<!-------logout model------------>
<?php require_once("logout.php");?>

<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js" ></script>
    
<script type="text/javascript">
    $(document).ready( function () {
        $('#table_id').DataTable();
    } );
</script>

</body>
</html>
