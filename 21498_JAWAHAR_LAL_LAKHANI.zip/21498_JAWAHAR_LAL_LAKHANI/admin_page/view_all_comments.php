<?php require_once("require/db_connection.php"); ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Users</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

    <script type="text/javascript" src="jquery.min.js"></script>

    <!-- Font Awesome CSS -->
    <style type="text/css">
        .navbar {
            background-color: #6DC5D1;
            padding: 1px;
        }

        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }


        .table-container {
            max-height: 400px; 
            overflow-y: auto;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-light sticky-top " style="border-bottom:1px dotted;">
    <div class="container-fluid">
        <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
            <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
            Jawahar Lal
        </a>
        <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#loginModal">LogOut</button>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <?php include_once("sidebaar.php"); ?> 
        <div class="col-md-9">
            <div class="content">
                <div class="container-fluid" style="padding-bottom: 50px;">
                    <h2>View All Comments</h2>
                    <!-- Adding a div with a scrollbar -->
                    <div class="table-container">
             <?php
                $query = "SELECT * FROM post_comment";
                  $result = mysqli_query($connection, $query);
            
                     if($result->num_rows)
            {
                ?>
                        <table id="table_id" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Post</th>
                                    <th>Comment</th>
                                    <th>is_Active</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while($data = mysqli_fetch_assoc($result))
                                {
                                    ?>
                              
                                <tr>
                                    <td><?php  echo $data["post_comment_id"]?></td>
                                    <td> <?php echo $data["post_id"] ?></td>
                                    <td><?php echo $data["user_id"] ?></td>
                                    <td> <?php echo $data["comment"] ?></td>
                                    <td>
                                        <button class="btn btn-success">Active</button>
                                        <button class="btn btn-danger">Inactive</button>
                                    </td>
                                    <td> <?php echo $data["created_at"] ?></td>
                                </tr>
                                <?php
                            }
                            ?>
                            </tbody>
                            <?php
            }
            else
            {
                ?>
                    <p style="color: red;"> No comment Found!...</p>
                <?php
            }
        ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Logout model -->
<?php require_once("logout.php");?>

<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>

<script type="text/javascript">
    $(document).ready( function () {
        $('#table_id').DataTable();
    });
</script>

</body>
</html>
