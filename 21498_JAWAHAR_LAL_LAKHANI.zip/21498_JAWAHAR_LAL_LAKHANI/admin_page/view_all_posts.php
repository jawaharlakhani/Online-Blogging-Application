<?php require_once("require/db_connection.php"); ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Users</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script type="text/javascript" src="jquery.min.js"></script>

    <style type="text/css">
        .navbar {
            background-color: #6DC5D1;
            padding: 1px;
        }

        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }

        .table-container {
            max-height: 400px; 
            overflow-y: auto;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-light sticky-top " style="border-bottom:1px dotted;">
    <div class="container-fluid">
        <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
            <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
            Jawahar Lal
        </a>
        <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#loginModal">LogOut</button>
    </div>
</nav>
<!---navbar-->

<div class="container-fluid ">
    <div class="row">
        <?php require_once("sidebaar.php"); ?> 
        <div class="col-md-9">
            <!-- View All Categories Section -->
        
            <div class="content">
                <div class="container-fluid" style="padding-bottom: 40px;">
                    <h2>View All Posts</h2>
                    <div class="table-container">
                        <?php
                            $query = "SELECT * FROM post";
                            $result = mysqli_query($connection, $query);

                            if ($result && $result->num_rows > 0) {
                        ?>
                        <table id="table_id" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Post ID</th>
                                    <th>Blog ID</th>
                                    <th>Post Title</th>
                                    <th>Post Summary</th>
                                    <th>Post Description</th>
                                    <th>Featured Image</th>
                                    <th>Post Status</th>
                                    <th>Is Comment Allowed</th>
                                    <th>Created At</th>
                                    <th>Updated At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    while ($data = mysqli_fetch_assoc($result)) {
                                ?>
                                <tr>
                                    <td><?php echo $data["post_id"] ?></td>
                                    <td><?php echo $data["blog_id"] ?></td>
                                    <td><?php echo $data["post_title"] ?></td>
                                    <td><?php echo $data["post_summary"] ?></td>
                                    <td><?php echo $data["post_description"] ?></td>
                                    <td><img src="Post_Images/<?php echo $data["featured_image"] ?>" width="60px" height="60px"></td>
                                    <td>
                                        <button class="btn btn-success">Active</button>
                                        <button class="btn btn-danger">Inactive</button>
                                    </td>
                                    <td><a href="?update_post=<?= $data['post_id'] ?>"><input type="submit" class="btn btn-success" name="update_post" value="Update"></a></td>
                                    <td><?php echo $data["is_comment_allowed"] ?></td>
                                    <td><?php echo $data["created_at"] ?></td>
                                    <td><?php echo $data["updated_at"] ?></td>
                                </tr>
                                <?php
                                    }
                                ?>
                            </tbody>
                        </table>
                        <?php
                            } else {
                        ?>
                        <p style="color: red;">Posts Not Found!...</p>
                        <?php
                            }
                        ?>
                    </div>
                </div>
            </div>
            <?php
                if (isset($_REQUEST['update_post'])) {
                    $sql = "SELECT * FROM post WHERE post_id = '" . $_REQUEST['update_post'] . "'";
                    $result = mysqli_query($connection, $sql);
                    if ($result) {
                        $data = mysqli_fetch_assoc($result);
                    }
            ?>  
            <h3 class="text-center" style="background-color:skyblue;">Update Post</h3>
            <?php
                if (isset($_GET["message"])) {
            ?>
                <p style="background-color:<?php echo $_GET["color"]; ?>; padding: 15px; text-align:center; margin: 30px; border-radius: 10px;"><?php echo $_GET["message"]; ?></p>
            <?php
                }
            ?>
            <form action="add_post_process.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="post_id" value="<?= $data['post_id'] ?>">
                <div class="mb-3">
                    <label for="title" class="form-label">Post Title</label>
                    <input type="text" class="form-control" id="post_title" name="post_title" value="<?= $data['post_title'] ?>">
                </div>
                <div class="mb-3">
                    <label for="post_summary" class="form-label">Post Summary</label>
                    <textarea class="form-control" id="post_summary" name="post_summary" rows="5"><?= $data['post_summary'] ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="post_description" class="form-label">Post Description</label>
                    <textarea class="form-control" id="post_description" name="post_description" rows="5"><?= $data['post_description'] ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="featured_image" class="form-label">Featured Image</label>
                    <input type="file" class="form-control" id="featured_image" name="featured_image">
                </div>
                <button type="submit" class="btn btn-primary" name="update_post">Update Post</button>
            </form>
            <?php
                }
            ?>
        </div>
    </div>
</div>

<?php require_once("logout.php");?>
<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<script type="text/javascript">
    $(document).ready( function () {
        $('#table_id').DataTable();
    });
</script>

</body>
</html>
