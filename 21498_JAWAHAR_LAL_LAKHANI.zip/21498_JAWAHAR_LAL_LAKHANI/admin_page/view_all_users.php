<?php require_once("require/db_connection.php");?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Users</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

    <script type="text/javascript" src="jquery.min.js"></script>

    <!-- Font Awesome CSS -->
    <style type="text/css">
        .navbar {
            background-color: #6DC5D1;
            padding: 1px;
        }

        .navbar-brand img {
            border-radius: 12px;
            width: 50px;
            height: auto;
        }

        

        /* Adding scrollbar to the table */
        .table-container {
            max-height: 300px; /* Adjust the height as needed */
            overflow-y: auto;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-light sticky-top " style="border-bottom:1px dotted;">
    <div class="container-fluid">
        <a class="navbar-brand text-dark" href="#" style="font-size: 25px;">
            <img src="https://assets.dryicons.com/uploads/icon/preview/8182/small_2x_84c1be73-a08f-4471-9e30-011685c3a070.png">
            Jawahar Lal
        </a>
        <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#loginModal">LogOut</button>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">
        <?php require_once("sidebaar.php"); ?> 
        <div class="col-md-9">
            <div class="content">
                <div class="container-fluid" style="padding-bottom: 50px;">
                    <h2>View All Users</h2>
                    <!-- Adding a div with a scrollbar -->
                    <div class="table-container">
                        <?php
                $query = "SELECT * FROM user";
                  $result = mysqli_query($connection, $query);
            
                     if($result->num_rows)
            {
                ?>
                        <table id="table_id" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>User Id</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    <th>Gender</th>
                                    <th>Date OF Birth</th>
                                    <th>User Image</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Is Active</th>
                                    <th>Created_at</th>
                                    <th>Updated_at</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Your table rows -->
                                <?php
                                while($data = mysqli_fetch_assoc($result))
                                {
                                    ?>
                                <tr>
                                    <td><?php echo $data["user_id"]?></td>
                                    <td><?php echo $data ["first_name"]?></td>
                                    <td><?php echo $data["last_name"] ?></td>
                                    <td><?php echo $data["email"] ?></td>
                                    <td><?php echo $data["password"]?></td>
                                    <td><?php echo $data["gender"]?></td>
                                    <td><?php echo $data["date_of_birth"]?></td>
                                    <td><img src="Images/<?php echo $data["user_image"]?>" width="60px" height="60px"></td>
                                    <td><?php echo $data["address"]?></td>
                                    <td><?php echo $data["is_approved"]?></td>
                                    <td>
                                        <button class="btn btn-success">Active</button>
                                        <button class="btn btn-danger">Inactive</button>
                                    </td>
                                    <td><a href="?update=<?= $data['user_id'] ?>"><input type="submit" class="btn btn-success" name="update" value="Update"></a></td>
                                    <td><?php echo $data["created_at"]?></td>
                                    <td><?php echo $data["updated_at"]?></td>
                                    
                                </tr>
                            </tbody>
                            <?php
                                }
                            ?>
                        </table>
                        <?php
            }
            else
            {
                ?>
                    <p style="color: red;">No User Found!...</p>
                <?php
            }
        ?>
                    </div>
                </div>
            </div>
            <?php
           if (isset($_REQUEST['update'])) {
            $sql = "SELECT * FROM user WHERE user_id = '".$_REQUEST['update']."'";
            $result=mysqli_query($connection,$sql);
            if ($result) {
                $data=mysqli_fetch_assoc($result);
            }
        ?>  
         <h3 class=" text-center " style="background-color:skyblue;">Update User</h3>
         <?php
                         if(isset($_GET["msg"]))
                                       {
                        ?>
                <p style="background-color:<?php echo $_GET["color"]; ?>; padding: 15px; text-align:center; margin: 30px; border-radius: 10px;"><?php echo $_GET["msg"]; ?></p>
                       <?php
                       }
                       ?>
         <form method="POST" action="add_user_process.php" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="firstName" class="form-label">First Name: </label>
                        <input type="text" class="form-control" id="firstName" name="firstName" value="<?= $data['first_name']?>">
                    </div>
                    <div class="mb-3">
                        <label for="lastName" class="form-label">Last Name:</label>
                        <input type="text" class="form-control" id="lastName" name="lastName" value="<?= $data['last_name']?>">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email address :</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= $data['email']?>">
                        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="Password" name="password" value="<?= $data['password']?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Gender <span>*</span></label>
                        <div class="form-check">
                            <input type="radio" name="gender" value="Male" <?= $data['gender'] == 'Male' ? 'checked' : '' ?>  /> Mele
                            <input type="radio" name="gender" value="Female"  <?= $data['gender'] == 'Female' ? 'checked' : '' ?> > Female
                        </div>
                    <div class="mb-3">
                        <label for="dob" class="form-label">Date of Birth : </label>
                        <input type="date" class="form-control" id="dob" name="dob" value="<?= $data['date_of_birth']?>"/>
                    </div>
                    <div class="mb-3">
            <label for="userImage" class="form-label">User Image:</label>
            <input type="file" class="form-control" id="profile_image" name="profile_image"/>
            <input type="hidden" name="existing_image" value="<?= $data['user_image'] ?>" />
        </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address :</label>
                        <textarea class="form-control" id="address" rows="3" name="address"><?= $data['address'] ?> </textarea>

                    </div>
                    <input type="hidden" name="user_id" value="<?= $data['user_id'] ?>">
                    <button type="submit" class="btn btn-primary d-block w-100" name="update">Submit</button>
                </form> 
                <?php

           }

            

        ?>
                
        </div>
    </div>
</div>

<!-- Logout model -->
<?php require_once("logout.php")?>
<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>

<script type="text/javascript">
    $(document).ready( function () {
        $('#table_id').DataTable();
    });
</script>

</body>
</html>
