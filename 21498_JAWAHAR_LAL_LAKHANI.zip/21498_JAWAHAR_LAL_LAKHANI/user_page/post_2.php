<?php require_once("../admin_page/require/db_connection.php");?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Panels</title>
  <link rel="stylesheet" type="text/css" href="../admin_page/bootstrap/css/bootstrap.min.css">

</head>
<style>
/* Profile Picture */
.profile-pic{
   display: inline-block;
   vertical-align: middle;
    width: 50px;
    height: 50px;
    overflow: hidden;
   border-radius: 50%;
}

.profile-pic img{
   width: 100%;
   height: auto;
   object-fit: cover;
}
.profile-menu .dropdown-menu {
  right: 0;
  left: unset;
}
.profile-menu .fa-fw {
  margin-right: 10px;
}

.toggle-change::after {
  border-top: 0;
  border-bottom: 0.3em solid;
}
nav{
  background-color: #6DC5D1;
}
.card-img-top {
        height: 500px; 
        width: 100%;
        object-fit: fixed; 
    }


</style>
<body>
<!------navbar----->
<nav class="navbar navbar-expand-lg ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">LAKHANI</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0 profile-menu"> 
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <div class="profile-pic">
                <img src="IMG_0024.JPG" alt="Profile Picture">
             </div>
         <!-- You can also use icon as follows: -->
           <!--  <i class="fas fa-user"></i> -->
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="accounts.php"><i class="fas fa-sliders-h fa-fw"></i> Account</a></li>
            <li><a class="dropdown-item" href="setting.php"><i class="fas fa-cog fa-fw"></i> Settings</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="../admin_page/index_page.php"><i class="fas fa-sign-out-alt fa-fw"></i> Log Out</a></li>
          </ul>
        </li>
     </ul>
    </div>
  </div>
</nav>
<!----navbar_end-->









<!---Posts----->

<div class="container-fluid py-5" style="background-color: #85C1E9; border: 1px dotted;">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-12">
                <div class="card mb-4">
                    <div class="card-body">
                       <?php
                        $query = "SELECT * FROM post";
                        $result = mysqli_query($connection, $query);
                        
                        if ($result->num_rows) {
                            $data=mysqli_fetch_assoc($result);                   
                            ?>   
                        <h5 class="card-title"><?php echo $data["post_title"] ?></h5>
                        <p class="card-text"><?php echo $data["post_description"] ?>
                        </p>
                        <?php
                      }
                      ?>
                    </div>
                        <!-- <a href="post_1.php" class="btn btn-primary">Read More &rarr;</a> -->
                    </div>
                    <section style="background-color:#CDE8E5;">
                <div class="container my-5 py-5 text-body">
                  <div class="row d-flex justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-6">
                      <div class="card">
                        <div class="card-body p-4">
                          <div class="d-flex flex-start w-100">
                            <img class="rounded-circle shadow-1-strong me-3"
                              src="IMG_0024.JPG" alt="avatar" width="68"
                              height="65" />
                            <div class="w-100">
                              <h5>Add a comment</h5>
                              <div data-mdb-input-init class="form-outline">
                                <textarea class="form-control" id="textAreaExample" rows="4"></textarea>
                                <label class="form-label" for="textAreaExample">What is your view?</label>
                              </div>
                              <div class="d-flex justify-content-between mt-3">
                                <button  type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary">
                                  Send <i class="fas fa-long-arrow-alt-right ms-1"></i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
    </div>
  </div>
</section>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript" src="../admin_page/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>









































