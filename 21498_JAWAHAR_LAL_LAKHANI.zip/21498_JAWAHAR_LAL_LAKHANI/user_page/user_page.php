<?php require_once("../admin_page/require/db_connection.php");?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Panels</title>
  <link rel="stylesheet" type="text/css" href="../admin_page/bootstrap/css/bootstrap.min.css">

</head>
<style>
/* Profile Picture */
.profile-pic{
   display: inline-block;
   vertical-align: middle;
    width: 50px;
    height: 50px;
    overflow: hidden;
   border-radius: 50%;
}

.profile-pic img{
   width: 100%;
   height: auto;
   object-fit: cover;
}
.profile-menu .dropdown-menu {
  right: 0;
  left: unset;
}
.profile-menu .fa-fw {
  margin-right: 10px;
}

.toggle-change::after {
  border-top: 0;
  border-bottom: 0.3em solid;
}
nav{
  background-color: #6DC5D1;
}
.card-img-top {
        height: 200px; 
        width: 100%;
        object-fit: cover; 
    }


</style>
<body>
<!------navbar----->
<nav class="navbar navbar-expand-lg ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">LAKHANI</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0 profile-menu"> 
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <div class="profile-pic">
                <img src="IMG_0024.JPG" alt="Profile Picture">
             </div>
         <!-- You can also use icon as follows: -->
           <!--  <i class="fas fa-user"></i> -->
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="accounts.php"><i class="fas fa-sliders-h fa-fw"></i> Account</a></li>
            <li><a class="dropdown-item" href="setting.php"><i class="fas fa-cog fa-fw"></i> Settings</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="../admin_page/index_page.php"><i class="fas fa-sign-out-alt fa-fw"></i> Log Out</a></li>
          </ul>
        </li>
     </ul>
    </div>
  </div>
</nav>
<!----navbar_end-->


<!---Posts----->

<div class="container-fluid py-5" style="background-color: #85C1E9; border: 1px dotted;">
    <div class="container">
        <div class="row">
                      <?php
                        $query = "SELECT * FROM post";
                        $result = mysqli_query($connection, $query);
                        
                        if ($result->num_rows) {
                          while($data=mysqli_fetch_assoc($result))  {
                            ?>   
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="../admin_page/Post_Images/<?php echo $data["featured_image"] ?>" width="200px" height="150px">
                    <div class="card-body">
                        <h5 class="card-title"><?php  echo $data["post_title"] ?></h5>
                        <p class="card-text"><?php echo $data["post_summary"]?></p>
                        <a href="post_1.php?post_id=<?php echo $data["post_id"]?>" class="btn btn-primary">Read More &rarr;</a>
                    </div>
                    <div class="card-footer text-muted">
                            Posted on <?php echo date('F j, Y', strtotime($data["created_at"])); ?> by Jawahar Lal
                        </div>
                </div>
            </div>
                <?php
              }
  
  }            ?>
            





<script type="text/javascript" src="../admin_page/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>









































